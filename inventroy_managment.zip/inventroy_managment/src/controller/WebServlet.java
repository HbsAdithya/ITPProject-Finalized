package controller;

public @interface WebServlet {

}
